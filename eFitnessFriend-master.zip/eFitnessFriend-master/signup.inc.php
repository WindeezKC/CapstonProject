<?php 

if (isset($_POST["submit"])){

$Email = $_POST['Email'];
$Password = $_POST['Password'];


function loginUser($con, $Email, $Password){

	 
}